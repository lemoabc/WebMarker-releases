var marker=(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,n=t,r=`wm-hl`,i=`data-wm-id`,a=new Set(`p.div.li.ol.ul.h1.h2.h3.h4.h5.h6.blockquote.pre.section.article.main.nav.aside.header.footer.table.thead.tbody.tfoot.tr.td.th.body.dd.dt.dl.figure.figcaption.details.summary`.split(`.`)),o={pen:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/></svg>`,trash:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>`,close:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M18 6L6 18"/><path d="M6 6l12 12"/></svg>`,more:`<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>`};function s(e){if(!e)return``;if(e===document.body)return`/html/body`;if(e===document.documentElement)return`/html`;if(e===document)return`/`;if(e.nodeType===Node.ELEMENT_NODE&&e.classList.contains(`wm-hl`))return s(e.parentElement);let t=e.parentElement;if(!t)return``;let n=e.tagName.toLowerCase(),r=Array.from(t.children).filter(e=>e.tagName&&e.tagName.toLowerCase()===n);return s(t)+`/`+n+`[`+(r.indexOf(e)+1)+`]`}function c(e){try{return document.evaluate(e,document,null,XPathResult.FIRST_ORDERED_NODE_TYPE,null).singleNodeValue}catch{return null}}function l(e,t,n){let r=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),i=0,a;for(;a=r.nextNode();){if(a===t)return i+n;i+=a.textContent.length}return null}function u(e){let t=e.nodeType===Node.TEXT_NODE?e.parentNode:e;for(;t&&t!==document.body&&t!==document.documentElement;){if(t.nodeType===Node.ELEMENT_NODE&&!t.classList.contains(`wm-hl`)&&a.has(t.tagName.toLowerCase()))return t;t=t.parentNode}return document.body}function d(e,t,n){let r=[],i=document.createTreeWalker(e,NodeFilter.SHOW_TEXT),a=0,o;for(;o=i.nextNode();){let e=a,i=a+o.textContent.length;if(i>t&&e<n){let i=Math.max(0,t-e),a=Math.min(o.textContent.length,n-e);if(i<a){let e=document.createRange();e.setStart(o,i),e.setEnd(o,a),r.push(e)}}if(a=i,a>=n)break}return r}function f(e,t,n,a,o,s){for(let c=e.length-1;c>=0;c--){let l=document.createElement(`span`);l.className=r,l.setAttribute(i,t),s?s(l,a,o):n===`highlight`?l.style.backgroundColor=a:l.style.color=a;try{e[c].surroundContents(l)}catch{let t=e[c].extractContents();l.appendChild(t),e[c].insertNode(l)}}}function p(e){document.querySelectorAll(`[`+i+`="`+e+`"]`).forEach(e=>{let t=e.parentNode;for(;e.firstChild;)t.insertBefore(e.firstChild,e);t.removeChild(e),t.normalize?.()})}function m(){document.querySelectorAll(`.`+r).forEach(e=>{let t=e.parentNode;for(;e.firstChild;)t.insertBefore(e.firstChild,e);t.removeChild(e),t.normalize?.()})}function h(){let e=document.createElement(`style`);e.id=`wm-page-css`,e.textContent=[`.`+r+`{border-radius:2px;padding:0 1px;transition:opacity .15s}`,`body.wm-eraser .`+r+`{outline:2px dashed rgba(255,82,82,.55);outline-offset:1px}`,`body.wm-eraser .`+r+`:hover{outline:2px solid #ff5252;opacity:.65}`].join(`
`),document.head.appendChild(e)}function g(e,t,n){return`url("data:image/svg+xml,`+encodeURIComponent(e)+`") `+t+` `+n+`, crosshair`}function _(e){return g(`<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32"><path d="M20 2L27 9L12 24L5 17Z" fill="#546E7A"/><path d="M22 4L27 9L25 11L20 6Z" fill="#78909C"/><path d="M12 24L5 17L2 27L4 30Z" fill="`+e+`"/><path d="M5 17L12 24L10 26L3 19Z" fill="`+e+`" opacity="0.6"/></svg>`,2,30)}function v(e){return g(`<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32"><path d="M28 1C21 5 13 13 8 23L10 25C15 15 21 7 28 1Z" fill="#A1887F" opacity="0.85"/><path d="M28 1C25 3 22 7 20 11L24 7Z" fill="#BCAAA4"/><path d="M8 23L4 31L6 31L10 25Z" fill="`+e+`"/><circle cx="4" cy="31" r="1.2" fill="`+e+`"/></svg>`,4,31)}function y(){return g(`<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32"><path d="M4 11L26 5L30 17L8 23Z" fill="#F5F5F5" stroke="#B0BEC5" stroke-width="1" stroke-linejoin="round"/><path d="M8 23L30 17L29 21L7 27Z" fill="#FF8A80" stroke="#EF9A9A" stroke-width="0.5" stroke-linejoin="round"/><path d="M6 17L28 11" stroke="#CFD8DC" stroke-width="0.8"/></svg>`,5,27)}function b(e){return g(`<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32"><rect x="8" y="2" width="14" height="22" rx="2" fill="#78909C" opacity="0.9"/><rect x="10" y="0" width="10" height="6" rx="1" fill="#90A4AE"/><rect x="7" y="22" width="16" height="8" rx="1" fill="`+e+`" opacity="0.8"/><rect x="9" y="24" width="12" height="4" rx="0.5" fill="`+e+`" opacity="0.5"/></svg>`,15,31)}function x(e){return g(`<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32"><path d="M6 4L6 20" stroke="#78909C" stroke-width="1.5" stroke-linecap="round"/><path d="M5 28L27 28" stroke="`+e+`" stroke-width="2.5" stroke-linecap="round"/><path d="M4 4L8 4" stroke="#90A4AE" stroke-width="1" stroke-linecap="round"/><circle cx="6" cy="2" r="1.2" fill="#B0BEC5"/></svg>`,6,30)}var S=null;function C(e){if(S||(S=document.createElement(`style`),S.id=`wm-cursor-css`,document.head.appendChild(S)),!e){S.textContent=``,document.body.classList.remove(`wm-active`);return}document.body.classList.add(`wm-active`),S.textContent=`body.wm-active,body.wm-active *{cursor:`+e+` !important}`}var w=new Map;function T(e){w.set(e.name,e)}function E(e){return w.get(e)}function ee(){return Array.from(w.values())}var D=[`#FFF176`,`#A5D6A7`,`#F48FB1`,`#81D4FA`,`#FFCC80`];T({name:`highlight`,icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`,label:`tool.highlight`,isAnnotator:!0,colors:D,defaultColor:D[0],cursor:e=>_(e),apply:(e,t)=>{e.style.backgroundColor=t}});var O=[`#E53935`,`#1E88E5`,`#43A047`,`#8E24AA`,`#EF6C00`];T({name:`textColor`,icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M6 20h12"/><path d="M12 4l-5 12h2.5l1.2-3h4.6l1.2 3H19L14 4h-4z" fill="currentColor" stroke="none"/></svg>`,label:`tool.textColor`,isAnnotator:!0,colors:O,defaultColor:O[0],cursor:e=>v(e),apply:(e,t)=>{e.style.color=t}});var k=[`#E53935`,`#1E88E5`,`#43A047`,`#8E24AA`,`#EF6C00`],A=[{name:`solid`,label:`style.solid`,icon:`─`},{name:`dashed`,label:`style.dashed`,icon:`┅`},{name:`wavy`,label:`style.wavy`,icon:`∿`},{name:`double`,label:`style.double`,icon:`═`},{name:`sketch`,label:`style.sketch`,icon:`〰`},{name:`marker`,label:`style.marker`,icon:`▬`}];function j(e){let t=[`M0,${8/2}`];for(let e=4;e<=200;e+=4){let n=8/2+(Math.random()-.5)*3;t.push(`L${e},${n.toFixed(1)}`)}let n=`<svg xmlns="http://www.w3.org/2000/svg" width="200" height="8"><path d="${t.join(` `)}" fill="none" stroke="${e}" stroke-width="1.5" stroke-linecap="round"/></svg>`;return`url("data:image/svg+xml,`+encodeURIComponent(n)+`")`}function M(e){let t=`<svg xmlns="http://www.w3.org/2000/svg" width="200" height="10"><rect x="0" y="1" width="200" height="6" rx="3" fill="${e}" opacity="0.55"/><rect x="2" y="2.5" width="196" height="3" rx="1.5" fill="${e}" opacity="0.35"/></svg>`;return`url("data:image/svg+xml,`+encodeURIComponent(t)+`")`}T({name:`underline`,icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><path d="M6 3v7a6 6 0 0 0 12 0V3"/><path d="M4 21h16"/></svg>`,label:`tool.underline`,isAnnotator:!0,styles:A,colors:k,defaultColor:k[0],defaultStyle:`solid`,cursor:e=>x(e),apply:(e,t,n)=>{let r=n||`solid`;if(r===`sketch`){e.style.backgroundImage=j(t),e.style.backgroundRepeat=`repeat-x`,e.style.backgroundPosition=`bottom left`,e.style.backgroundSize=`auto 6px`,e.style.paddingBottom=`3px`;return}if(r===`marker`){e.style.backgroundImage=M(t),e.style.backgroundRepeat=`repeat-x`,e.style.backgroundPosition=`bottom left`,e.style.backgroundSize=`auto 8px`,e.style.paddingBottom=`4px`;return}e.style.textDecoration=`underline ${r}`,e.style.textDecorationColor=t,e.style.textDecorationThickness=r===`double`?`1px`:`2px`,e.style.textUnderlineOffset=`3px`}});var N=null,P=new Set;function F(){return N||(N=document.createElementNS(`http://www.w3.org/2000/svg`,`svg`),N.setAttribute(`width`,`0`),N.setAttribute(`height`,`0`),N.style.cssText=`position:absolute;width:0;height:0;overflow:hidden;pointer-events:none;`,document.body.appendChild(N),N)}function te(e){return e.replace(`#`,``)}function I(e,t){return`wm-${e}-${te(t)}`}function L(e){return`<filter id="${I(`felt`,e)}" x="-5%" y="-30%" width="110%" height="160%">
    <feTurbulence type="fractalNoise" baseFrequency="0.04 0.15" numOctaves="4" seed="2" result="noise"/>
    <feDisplacementMap in="SourceGraphic" in2="noise" scale="3" xChannelSelector="R" yChannelSelector="G"/>
  </filter>`}function R(e){return`<filter id="${I(`watercolor`,e)}" x="-10%" y="-40%" width="120%" height="180%">
    <feTurbulence type="fractalNoise" baseFrequency="0.03 0.06" numOctaves="3" seed="5" result="noise"/>
    <feDisplacementMap in="SourceGraphic" in2="noise" scale="4" xChannelSelector="R" yChannelSelector="G" result="displaced"/>
    <feGaussianBlur in="displaced" stdDeviation="0.8" result="blurred"/>
    <feComposite in="blurred" in2="SourceGraphic" operator="atop"/>
  </filter>`}function ne(e){return`<filter id="${I(`crayon`,e)}" x="-3%" y="-20%" width="106%" height="140%">
    <feTurbulence type="turbulence" baseFrequency="0.65 0.3" numOctaves="5" seed="8" result="noise"/>
    <feColorMatrix in="noise" type="luminanceToAlpha" result="alpha"/>
    <feComponentTransfer in="alpha" result="thresh">
      <feFuncA type="discrete" tableValues="0 0 0.5 1 1"/>
    </feComponentTransfer>
    <feComposite in="SourceGraphic" in2="thresh" operator="in"/>
  </filter>`}var re={felt:L,watercolor:R,crayon:ne};function ie(e,t){if(e===`neon`)return``;let n=I(e,t);if(P.has(n))return n;let r=re[e];if(!r)return``;let i=F(),a=r(t),o=document.createElementNS(`http://www.w3.org/2000/svg`,`svg`);o.innerHTML=a;let s=o.firstElementChild;return s&&i.appendChild(s),P.add(n),n}var z=[`#FFF176`,`#A5D6A7`,`#F48FB1`,`#81D4FA`,`#FFCC80`],ae=[{name:`felt`,label:`texture.felt`,icon:`🖍`},{name:`watercolor`,label:`texture.watercolor`,icon:`💧`},{name:`crayon`,label:`texture.crayon`,icon:`🖊`},{name:`neon`,label:`texture.neon`,icon:`✦`}];function oe(e){let t=e.replace(`#`,``);return{r:parseInt(t.substring(0,2),16),g:parseInt(t.substring(2,4),16),b:parseInt(t.substring(4,6),16)}}T({name:`brushHighlight`,icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.37 2.63a2.12 2.12 0 0 1 3 3L14 13l-4 1 1-4 7.37-7.37z"/><path d="M9 15H5a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h4"/><path d="M15 9l3 3"/></svg>`,label:`tool.brushHighlight`,isAnnotator:!0,styles:ae,colors:z,defaultColor:z[0],defaultStyle:`felt`,cursor:e=>b(e),apply:(e,t,n)=>{let r=n||`felt`;if(r===`neon`){let n=oe(t);e.style.backgroundColor=`rgba(${n.r},${n.g},${n.b},0.15)`,e.style.boxShadow=`0 0 4px rgba(${n.r},${n.g},${n.b},0.4), 0 0 8px rgba(${n.r},${n.g},${n.b},0.2)`,e.style.borderRadius=`3px`,e.style.padding=`1px 2px`;return}e.style.backgroundColor=t,e.style.borderRadius=`2px`,e.style.padding=`1px 2px`;let i=ie(r,t);i&&(e.style.filter=`url(#${i})`)}}),T({name:`eraser`,icon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 20H7.5l-3.2-3.2a2 2 0 0 1 0-2.8L14.8 3.5a2 2 0 0 1 2.8 0l3.9 3.9a2 2 0 0 1 0 2.8L11 20"/><path d="M6 14l8-8"/></svg>`,label:`tool.eraser`,isAnnotator:!1,colors:[],defaultColor:``,cursor:()=>y(),apply:()=>{}});var B={zh:{"tool.highlight":`高亮`,"tool.textColor":`字色`,"tool.underline":`下划线`,"tool.brushHighlight":`刷痕`,"tool.eraser":`擦除`,"tool.clearAll":`清除`,"style.solid":`实线`,"style.dashed":`虚线`,"style.wavy":`波浪`,"style.double":`双线`,"style.sketch":`手绘`,"style.marker":`马克笔`,"texture.felt":`马克笔`,"texture.watercolor":`水彩`,"texture.crayon":`蜡笔`,"texture.neon":`霓虹`,"ui.color":`颜色`,"ui.style":`样式`,"ui.clearAllTitle":`清除全部`,"ui.customColor":`自定义颜色`,"ui.customColorPro":`自定义颜色 (Pro)`,"ui.expandPanel":`展开完整面板`,"ui.clickToAnnotate":`点击即可标注`,"ui.recentColors":`最近使用`,"ui.onboardTip":`选中文字即可标注 ✨`,"ai.mode.speed-read":`速读`,"ai.mode.research":`研究`,"ai.mode.critical":`批判`,"ai.mode.learning":`学习`,"ai.mode.custom":`自定义`,"ai.presetModes":`预设阅读模式`,"ai.customIntent":`自定义意图`,"ai.batchHistory":`历史批次`,"ai.status.idle":`就绪`,"ai.status.processing":`正在标注...`,"ai.status.complete":`标注完成`,"ai.status.error":`标注失败`,"ai.inputPlaceholder":`输入你的阅读意图...`,"ai.polish":`AI 润色`,"ai.polishing":`润色中...`,"ai.restoreOriginal":`↩ 恢复原文`,"ai.shuffle":`🔄 换一批`,"ai.startAnnotate":`开始标注`,"ai.stopAnnotate":`⏹ 停止标注`,"ai.retry":`重试`,"ai.annotated":`已标注 {count} 处`,"ai.completeMsg":`✓ 标注完成 · 共 {count} 处`,"ai.clearBatch":`清除此批次`,"ai.color":`标注颜色`,"ai.scrollContinue":`滚动续标中...`,"ai.scrollStopped":`续标已停止`,"ai.scrollMaxScreens":`已达最大屏数`,"popup.pageAnnotations":`当前页面标注`,"popup.enableAnnotation":`启用标注`,"popup.export":`导出标注`,"popup.import":`导入标注`,"popup.noAnnotations":`无标注`,"popup.exported":`已导出`,"popup.formatError":`格式错误`,"popup.importFailed":`导入失败`,"popup.fileUrlHint":`提示：本地文件需在扩展详情页开启「允许访问文件网址」`,"popup.freeVersion":`免费版`,"popup.activatePro":`激活 Pro`,"popup.emailPlaceholder":`邮箱`,"popup.keyPlaceholder":`许可证密钥`,"popup.verify":`验证`,"popup.verifying":`验证中...`,"popup.fillComplete":`请填写完整`,"popup.language":`语言`},en:{"tool.highlight":`Highlight`,"tool.textColor":`Text Color`,"tool.underline":`Underline`,"tool.brushHighlight":`Brush`,"tool.eraser":`Eraser`,"tool.clearAll":`Clear`,"style.solid":`Solid`,"style.dashed":`Dashed`,"style.wavy":`Wavy`,"style.double":`Double`,"style.sketch":`Sketch`,"style.marker":`Marker`,"texture.felt":`Felt Tip`,"texture.watercolor":`Watercolor`,"texture.crayon":`Crayon`,"texture.neon":`Neon`,"ui.color":`Color`,"ui.style":`Style`,"ui.clearAllTitle":`Clear All`,"ui.customColor":`Custom Color`,"ui.customColorPro":`Custom Color (Pro)`,"ui.expandPanel":`Expand Panel`,"ui.clickToAnnotate":`Click to annotate`,"ui.recentColors":`Recent`,"ui.onboardTip":`Select text to annotate ✨`,"ai.mode.speed-read":`Speed Read`,"ai.mode.research":`Research`,"ai.mode.critical":`Critical`,"ai.mode.learning":`Learning`,"ai.mode.custom":`Custom`,"ai.presetModes":`Preset Modes`,"ai.customIntent":`Custom Intent`,"ai.batchHistory":`Batch History`,"ai.status.idle":`Ready`,"ai.status.processing":`Annotating...`,"ai.status.complete":`Complete`,"ai.status.error":`Failed`,"ai.inputPlaceholder":`Enter your reading intent...`,"ai.polish":`AI Polish`,"ai.polishing":`Polishing...`,"ai.restoreOriginal":`↩ Restore`,"ai.shuffle":`🔄 Shuffle`,"ai.startAnnotate":`Start`,"ai.stopAnnotate":`⏹ Stop`,"ai.retry":`Retry`,"ai.annotated":`{count} annotated`,"ai.completeMsg":`✓ Done · {count} annotations`,"ai.clearBatch":`Clear batch`,"ai.color":`Color`,"ai.scrollContinue":`Auto-continuing...`,"ai.scrollStopped":`Scroll stopped`,"ai.scrollMaxScreens":`Max screens reached`,"popup.pageAnnotations":`Page Annotations`,"popup.enableAnnotation":`Enable`,"popup.export":`Export`,"popup.import":`Import`,"popup.noAnnotations":`None`,"popup.exported":`Exported`,"popup.formatError":`Bad format`,"popup.importFailed":`Failed`,"popup.fileUrlHint":`Tip: Enable "Allow access to file URLs" in extension details for local files`,"popup.freeVersion":`Free`,"popup.activatePro":`Activate Pro`,"popup.emailPlaceholder":`Email`,"popup.keyPlaceholder":`License Key`,"popup.verify":`Verify`,"popup.verifying":`Verifying...`,"popup.fillComplete":`Please fill all fields`,"popup.language":`Language`}},V=`zh`;function se(e){V=e.startsWith(`zh`)?`zh`:B[e]?e:`en`}function H(){return(navigator.language||`zh-CN`).startsWith(`zh`)?`zh`:`en`}function U(e){return(B[V]||B.zh)[e]||B.zh[e]||e}var ce=`
  .wm-picker{
    display:flex;flex-direction:column;gap:6px;
    padding:6px 0 0;
  }
  .wm-picker-canvas-wrap{
    position:relative;width:144px;height:100px;
    border-radius:6px;overflow:hidden;cursor:crosshair;
  }
  .wm-picker-canvas{
    width:144px;height:100px;display:block;
  }
  .wm-picker-thumb{
    position:absolute;width:12px;height:12px;
    border:2px solid #fff;border-radius:50%;
    box-shadow:0 0 3px rgba(0,0,0,.5);
    pointer-events:none;transform:translate(-50%,-50%);
  }
  .wm-hue-wrap{
    position:relative;width:144px;height:14px;
    border-radius:7px;overflow:hidden;cursor:pointer;
  }
  .wm-hue-bar{
    width:100%;height:100%;
    background:linear-gradient(to right,
      hsl(0,100%,50%),hsl(60,100%,50%),hsl(120,100%,50%),
      hsl(180,100%,50%),hsl(240,100%,50%),hsl(300,100%,50%),hsl(360,100%,50%)
    );
  }
  .wm-hue-thumb{
    position:absolute;top:0;width:4px;height:100%;
    background:#fff;border-radius:2px;
    box-shadow:0 0 3px rgba(0,0,0,.4);
    pointer-events:none;transform:translateX(-50%);
  }
  .wm-hex-row{
    display:flex;align-items:center;gap:4px;
  }
  .wm-hex-label{
    font-size:10px;color:rgba(255,255,255,.45);flex-shrink:0;
  }
  .wm-hex-input{
    width:80px;height:22px;border:1px solid rgba(255,255,255,.15);
    border-radius:4px;background:rgba(255,255,255,.08);
    color:#fff;font-size:11px;font-family:monospace;
    padding:0 4px;outline:none;
  }
  .wm-hex-input:focus{border-color:#64B5F6}
  .wm-picker-preview{
    width:22px;height:22px;border-radius:4px;
    border:1px solid rgba(255,255,255,.2);flex-shrink:0;
  }
  .wm-recent-row{
    display:flex;flex-wrap:wrap;gap:4px;
  }
  .wm-recent-dot{
    width:16px;height:16px;border-radius:50%;
    border:1.5px solid transparent;cursor:pointer;
    transition:transform .1s;
  }
  .wm-recent-dot:hover{transform:scale(1.2)}
`;function W(e,t,n){let r=0,i=0,a=0,o=Math.floor(e*6),s=e*6-o,c=n*(1-t),l=n*(1-s*t),u=n*(1-(1-s)*t);switch(o%6){case 0:r=n,i=u,a=c;break;case 1:r=l,i=n,a=c;break;case 2:r=c,i=n,a=u;break;case 3:r=c,i=l,a=n;break;case 4:r=u,i=c,a=n;break;case 5:r=n,i=c,a=l;break}return[Math.round(r*255),Math.round(i*255),Math.round(a*255)]}function le(e,t,n){return`#`+[e,t,n].map(e=>e.toString(16).padStart(2,`0`)).join(``).toUpperCase()}function ue(e){let t=e.replace(`#`,``),n=parseInt(t.substring(0,2),16)/255,r=parseInt(t.substring(2,4),16)/255,i=parseInt(t.substring(4,6),16)/255,a=Math.max(n,r,i),o=a-Math.min(n,r,i),s=0;o!==0&&(s=a===n?((r-i)/o+6)%6/6:a===r?((i-n)/o+2)/6:((n-r)/o+4)/6);let c=a===0?0:o/a;return[s,c,a]}function de(e,t,n){let[r,i,a]=ue(e),o=document.createElement(`style`);o.textContent=ce;let s=document.createElement(`div`);s.className=`wm-picker`;let c=document.createElement(`div`);c.className=`wm-picker-canvas-wrap`;let l=document.createElement(`canvas`);l.className=`wm-picker-canvas`,l.width=144,l.height=100,c.appendChild(l);let u=document.createElement(`div`);u.className=`wm-picker-thumb`,c.appendChild(u),s.appendChild(c);let d=document.createElement(`div`);d.className=`wm-hue-wrap`;let f=document.createElement(`div`);f.className=`wm-hue-bar`,d.appendChild(f);let p=document.createElement(`div`);p.className=`wm-hue-thumb`,d.appendChild(p),s.appendChild(d);let m=document.createElement(`div`);m.className=`wm-hex-row`;let h=document.createElement(`span`);h.className=`wm-hex-label`,h.textContent=`HEX`;let g=document.createElement(`input`);g.className=`wm-hex-input`,g.type=`text`,g.maxLength=7;let _=document.createElement(`div`);if(_.className=`wm-picker-preview`,m.appendChild(h),m.appendChild(g),m.appendChild(_),s.appendChild(m),t.length>0){let e=document.createElement(`div`);e.className=`wm-hex-label`,e.textContent=U(`ui.recentColors`),e.style.marginTop=`2px`,s.appendChild(e);let r=document.createElement(`div`);r.className=`wm-recent-row`,t.forEach(e=>{let t=document.createElement(`div`);t.className=`wm-recent-dot`,t.style.background=e,t.title=e,t.addEventListener(`click`,t=>{t.stopPropagation(),b(e),n(e)}),r.appendChild(t)}),s.appendChild(r)}function v(){let e=l.getContext(`2d`),t=l.width,n=l.height,i=W(r,1,1),a=e.createLinearGradient(0,0,t,0);a.addColorStop(0,`#FFFFFF`),a.addColorStop(1,`rgb(${i[0]},${i[1]},${i[2]})`),e.fillStyle=a,e.fillRect(0,0,t,n);let o=e.createLinearGradient(0,0,0,n);o.addColorStop(0,`rgba(0,0,0,0)`),o.addColorStop(1,`rgba(0,0,0,1)`),e.fillStyle=o,e.fillRect(0,0,t,n)}function y(){v(),u.style.left=i*144+`px`,u.style.top=(1-a)*100+`px`,p.style.left=r*144+`px`;let[e,t,n]=W(r,i,a),o=le(e,t,n);g.value=o,_.style.background=o}function b(e){[r,i,a]=ue(e),y()}function x(){let[e,t,o]=W(r,i,a);n(le(e,t,o))}let S=!1;function C(e){let t=l.getBoundingClientRect();i=Math.max(0,Math.min(1,(e.clientX-t.left)/t.width)),a=Math.max(0,Math.min(1,1-(e.clientY-t.top)/t.height)),y(),x()}c.addEventListener(`mousedown`,e=>{S=!0,C(e)}),document.addEventListener(`mousemove`,e=>{S&&C(e)}),document.addEventListener(`mouseup`,()=>{S=!1});let w=!1;function T(e){let t=d.getBoundingClientRect();r=Math.max(0,Math.min(1,(e.clientX-t.left)/t.width)),y(),x()}return d.addEventListener(`mousedown`,e=>{w=!0,T(e)}),document.addEventListener(`mousemove`,e=>{w&&T(e)}),document.addEventListener(`mouseup`,()=>{w=!1}),g.addEventListener(`change`,()=>{let e=g.value.trim();e.startsWith(`#`)||(e=`#`+e),/^#[0-9A-Fa-f]{6}$/.test(e)&&(b(e),x())}),y(),{element:s,setColor:b,getStyleElement:()=>o}}var fe=Error(`request for lock canceled`),pe=function(e,t,n,r){function i(e){return e instanceof n?e:new n(function(t){t(e)})}return new(n||=Promise)(function(n,a){function o(e){try{c(r.next(e))}catch(e){a(e)}}function s(e){try{c(r.throw(e))}catch(e){a(e)}}function c(e){e.done?n(e.value):i(e.value).then(o,s)}c((r=r.apply(e,t||[])).next())})},me=class{constructor(e,t=fe){this._value=e,this._cancelError=t,this._queue=[],this._weightedWaiters=[]}acquire(e=1,t=0){if(e<=0)throw Error(`invalid weight ${e}: must be positive`);return new Promise((n,r)=>{let i={resolve:n,reject:r,weight:e,priority:t},a=ge(this._queue,e=>t<=e.priority);a===-1&&e<=this._value?this._dispatchItem(i):this._queue.splice(a+1,0,i)})}runExclusive(e){return pe(this,arguments,void 0,function*(e,t=1,n=0){let[r,i]=yield this.acquire(t,n);try{return yield e(r)}finally{i()}})}waitForUnlock(e=1,t=0){if(e<=0)throw Error(`invalid weight ${e}: must be positive`);return this._couldLockImmediately(e,t)?Promise.resolve():new Promise(n=>{this._weightedWaiters[e-1]||(this._weightedWaiters[e-1]=[]),he(this._weightedWaiters[e-1],{resolve:n,priority:t})})}isLocked(){return this._value<=0}getValue(){return this._value}setValue(e){this._value=e,this._dispatchQueue()}release(e=1){if(e<=0)throw Error(`invalid weight ${e}: must be positive`);this._value+=e,this._dispatchQueue()}cancel(){this._queue.forEach(e=>e.reject(this._cancelError)),this._queue=[]}_dispatchQueue(){for(this._drainUnlockWaiters();this._queue.length>0&&this._queue[0].weight<=this._value;)this._dispatchItem(this._queue.shift()),this._drainUnlockWaiters()}_dispatchItem(e){let t=this._value;this._value-=e.weight,e.resolve([t,this._newReleaser(e.weight)])}_newReleaser(e){let t=!1;return()=>{t||(t=!0,this.release(e))}}_drainUnlockWaiters(){if(this._queue.length===0)for(let e=this._value;e>0;e--){let t=this._weightedWaiters[e-1];t&&(t.forEach(e=>e.resolve()),this._weightedWaiters[e-1]=[])}else{let e=this._queue[0].priority;for(let t=this._value;t>0;t--){let n=this._weightedWaiters[t-1];if(!n)continue;let r=n.findIndex(t=>t.priority<=e);(r===-1?n:n.splice(0,r)).forEach((e=>e.resolve()))}}}_couldLockImmediately(e,t){return(this._queue.length===0||this._queue[0].priority<t)&&e<=this._value}};function he(e,t){let n=ge(e,e=>t.priority<=e.priority);e.splice(n+1,0,t)}function ge(e,t){for(let n=e.length-1;n>=0;n--)if(t(e[n]))return n;return-1}var _e=function(e,t,n,r){function i(e){return e instanceof n?e:new n(function(t){t(e)})}return new(n||=Promise)(function(n,a){function o(e){try{c(r.next(e))}catch(e){a(e)}}function s(e){try{c(r.throw(e))}catch(e){a(e)}}function c(e){e.done?n(e.value):i(e.value).then(o,s)}c((r=r.apply(e,t||[])).next())})},ve=class{constructor(e){this._semaphore=new me(1,e)}acquire(){return _e(this,arguments,void 0,function*(e=0){let[,t]=yield this._semaphore.acquire(1,e);return t})}runExclusive(e,t=0){return this._semaphore.runExclusive(()=>e(),1,t)}isLocked(){return this._semaphore.isLocked()}waitForUnlock(e=0){return this._semaphore.waitForUnlock(1,e)}release(){this._semaphore.isLocked()&&this._semaphore.release()}cancel(){return this._semaphore.cancel()}},ye=Object.prototype.hasOwnProperty;function G(e,t){var n,r;if(e===t)return!0;if(e&&t&&(n=e.constructor)===t.constructor){if(n===Date)return e.getTime()===t.getTime();if(n===RegExp)return e.toString()===t.toString();if(n===Array){if((r=e.length)===t.length)for(;r--&&G(e[r],t[r]););return r===-1}if(!n||typeof e==`object`){for(n in r=0,e)if(ye.call(e,n)&&++r&&!ye.call(t,n)||!(n in t)||!G(e[n],t[n]))return!1;return Object.keys(t).length===r}}return e!==e&&t!==t}var K=be();function be(){let e={local:q(`local`),session:q(`session`),sync:q(`sync`),managed:q(`managed`)},n=t=>{let n=e[t];if(n==null){let n=Object.keys(e).join(`, `);throw Error(`Invalid area "${t}". Options: ${n}`)}return n},r=e=>{let t=e.indexOf(`:`),r=e.substring(0,t),i=e.substring(t+1);if(i==null)throw Error(`Storage key should be in the form of "area:key", but received "${e}"`);return{driverArea:r,driverKey:i,driver:n(r)}},i=e=>e+`$`,a=(e,t)=>{let n={...e};return Object.entries(t).forEach(([e,t])=>{t==null?delete n[e]:n[e]=t}),n},o=(e,t)=>e??t??null,s=e=>typeof e==`object`&&!Array.isArray(e)?e:{},c=async(e,t,n)=>o(await e.getItem(t),n?.fallback??n?.defaultValue),l=async(e,t)=>{let n=i(t);return s(await e.getItem(n))},u=async(e,t,n)=>{await e.setItem(t,n??null)},d=async(e,t,n)=>{let r=i(t),o=s(await e.getItem(r));await e.setItem(r,a(o,n))},f=async(e,t,n)=>{if(await e.removeItem(t),n?.removeMeta){let n=i(t);await e.removeItem(n)}},p=async(e,t,n)=>{let r=i(t);if(n==null)await e.removeItem(r);else{let t=s(await e.getItem(r));[n].flat().forEach(e=>delete t[e]),await e.setItem(r,t)}},m=(e,t,n)=>e.watch(t,n);return{getItem:async(e,t)=>{let{driver:n,driverKey:i}=r(e);return await c(n,i,t)},getItems:async t=>{let n=new Map,i=new Map,a=[];t.forEach(e=>{let t,o;typeof e==`string`?t=e:`getValue`in e?(t=e.key,o={fallback:e.fallback}):(t=e.key,o=e.options),a.push(t);let{driverArea:s,driverKey:c}=r(t),l=n.get(s)??[];n.set(s,l.concat(c)),i.set(t,o)});let s=new Map;return await Promise.all(Array.from(n.entries()).map(async([t,n])=>{(await e[t].getItems(n)).forEach(e=>{let n=`${t}:${e.key}`,r=i.get(n),a=o(e.value,r?.fallback??r?.defaultValue);s.set(n,a)})})),a.map(e=>({key:e,value:s.get(e)}))},getMeta:async e=>{let{driver:t,driverKey:n}=r(e);return await l(t,n)},getMetas:async e=>{let n=e.map(e=>{let t=typeof e==`string`?e:e.key,{driverArea:n,driverKey:a}=r(t);return{key:t,driverArea:n,driverKey:a,driverMetaKey:i(a)}}),a=n.reduce((e,t)=>(e[t.driverArea]??=[],e[t.driverArea].push(t),e),{}),o={};return await Promise.all(Object.entries(a).map(async([e,n])=>{let r=await t.storage[e].get(n.map(e=>e.driverMetaKey));n.forEach(e=>{o[e.key]=r[e.driverMetaKey]??{}})})),n.map(e=>({key:e.key,meta:o[e.key]}))},setItem:async(e,t)=>{let{driver:n,driverKey:i}=r(e);await u(n,i,t)},setItems:async e=>{let t={};e.forEach(e=>{let{driverArea:n,driverKey:i}=r(`key`in e?e.key:e.item.key);t[n]??=[],t[n].push({key:i,value:e.value})}),await Promise.all(Object.entries(t).map(async([e,t])=>{await n(e).setItems(t)}))},setMeta:async(e,t)=>{let{driver:n,driverKey:i}=r(e);await d(n,i,t)},setMetas:async e=>{let t={};e.forEach(e=>{let{driverArea:n,driverKey:i}=r(`key`in e?e.key:e.item.key);t[n]??=[],t[n].push({key:i,properties:e.meta})}),await Promise.all(Object.entries(t).map(async([e,t])=>{let r=n(e),o=t.map(({key:e})=>i(e)),c=await r.getItems(o),l=Object.fromEntries(c.map(({key:e,value:t})=>[e,s(t)])),u=t.map(({key:e,properties:t})=>{let n=i(e);return{key:n,value:a(l[n]??{},t)}});await r.setItems(u)}))},removeItem:async(e,t)=>{let{driver:n,driverKey:i}=r(e);await f(n,i,t)},removeItems:async e=>{let t={};e.forEach(e=>{let n,a;typeof e==`string`?n=e:`getValue`in e?n=e.key:`item`in e?(n=e.item.key,a=e.options):(n=e.key,a=e.options);let{driverArea:o,driverKey:s}=r(n);t[o]??=[],t[o].push(s),a?.removeMeta&&t[o].push(i(s))}),await Promise.all(Object.entries(t).map(async([e,t])=>{await n(e).removeItems(t)}))},clear:async e=>{await n(e).clear()},removeMeta:async(e,t)=>{let{driver:n,driverKey:i}=r(e);await p(n,i,t)},snapshot:async(e,t)=>{let r=await n(e).snapshot();return t?.excludeKeys?.forEach(e=>{delete r[e],delete r[i(e)]}),r},restoreSnapshot:async(e,t)=>{await n(e).restoreSnapshot(t)},watch:(e,t)=>{let{driver:n,driverKey:i}=r(e);return m(n,i,t)},unwatch(){Object.values(e).forEach(e=>{e.unwatch()})},defineItem:(e,t)=>{let{driver:n,driverKey:a}=r(e),{version:o=1,migrations:s={},onMigrationComplete:h,debug:g=!1}=t??{};if(o<1)throw Error(`Storage item version cannot be less than 1. Initial versions should be set to 1, not 0.`);let _=!1,v=async()=>{let t=i(a),[{value:r},{value:c}]=await n.getItems([a,t]);if(_=r==null&&c?.v==null&&!!o,r==null)return;let l=c?.v??1;if(l>o)throw Error(`Version downgrade detected (v${l} -> v${o}) for "${e}"`);if(l===o)return;g&&console.debug(`[@wxt-dev/storage] Running storage migration for ${e}: v${l} -> v${o}`);let u=Array.from({length:o-l},(e,t)=>l+t+1),d=r;for(let t of u)try{d=await s?.[t]?.(d)??d,g&&console.debug(`[@wxt-dev/storage] Storage migration processed for version: v${t}`)}catch(n){throw new xe(e,t,{cause:n})}await n.setItems([{key:a,value:d},{key:t,value:{...c,v:o}}]),g&&console.debug(`[@wxt-dev/storage] Storage migration completed for ${e} v${o}`,{migratedValue:d}),h?.(d,o)},y=t?.migrations==null?Promise.resolve():v().catch(t=>{console.error(`[@wxt-dev/storage] Migration failed for ${e}`,t)}),b=new ve,x=()=>t?.fallback??t?.defaultValue??null,S=()=>b.runExclusive(async()=>{let e=await n.getItem(a);if(e!=null||t?.init==null)return e;let r=await t.init();return await n.setItem(a,r),e==null&&o>1&&await d(n,a,{v:o}),r});return y.then(S),{key:e,get defaultValue(){return x()},get fallback(){return x()},getValue:async()=>(await y,t?.init?await S():await c(n,a,t)),getMeta:async()=>(await y,await l(n,a)),setValue:async e=>{await y,_?(_=!1,await Promise.all([u(n,a,e),d(n,a,{v:o})])):await u(n,a,e)},setMeta:async e=>(await y,await d(n,a,e)),removeValue:async e=>(await y,await f(n,a,e)),removeMeta:async e=>(await y,await p(n,a,e)),watch:e=>m(n,a,(t,n)=>e(t??x(),n??x())),migrate:v}}}}function q(e){let n=()=>{if(t.runtime==null)throw Error(`'wxt/storage' must be loaded in a web extension environment

 - If thrown during a build, see https://github.com/wxt-dev/wxt/issues/371
 - If thrown during tests, mock 'wxt/browser' correctly. See https://wxt.dev/guide/go-further/testing.html
`);if(t.storage==null)throw Error(`You must add the 'storage' permission to your manifest to use 'wxt/storage'`);let n=t.storage[e];if(n==null)throw Error(`"browser.storage.${e}" is undefined`);return n},r=new Set;return{getItem:async e=>(await n().get(e))[e],getItems:async e=>{let t=await n().get(e);return e.map(e=>({key:e,value:t[e]??null}))},setItem:async(e,t)=>{t==null?await n().remove(e):await n().set({[e]:t})},setItems:async e=>{let t=e.reduce((e,{key:t,value:n})=>(e[t]=n,e),{});await n().set(t)},removeItem:async e=>{await n().remove(e)},removeItems:async e=>{await n().remove(e)},clear:async()=>{await n().clear()},snapshot:async()=>await n().get(),restoreSnapshot:async e=>{await n().set(e)},watch(e,t){let i=n=>{let r=n[e];r==null||G(r.newValue,r.oldValue)||t(r.newValue??null,r.oldValue??null)};return n().onChanged.addListener(i),r.add(i),()=>{n().onChanged.removeListener(i),r.delete(i)}},unwatch(){r.forEach(e=>{n().onChanged.removeListener(e)}),r.clear()}}}var xe=class extends Error{constructor(e,t,n){super(`v${t} migration failed for "${e}"`,n),this.key=e,this.version=t}},J={miniToolbarSlots:[`highlight`,`textColor`,`underline`],toolConfigs:{highlight:{color:`#FFF176`},textColor:{color:`#E53935`},underline:{color:`#E53935`,style:`solid`},brushHighlight:{color:`#FFF176`,style:`felt`}},onboardingDone:!1,firstAnnotationDone:!1},Se={status:`idle`,currentMode:null,currentBatchId:null,processedScreens:0,lastError:null,renderedCount:0};function Ce(){return{open:!1,annotateMode:!1,tool:null,color:null,style:null,annotations:[],prefs:{...J,toolConfigs:{...J.toolConfigs}},ai:{...Se}}}function we(){return`local:wm::`+location.href}async function Te(){let e=await K.getItem(we());return e&&Array.isArray(e.annotations)?e.annotations:[]}async function Y(e){await K.setItem(we(),{v:1,url:location.href,annotations:e.annotations})}async function Ee(e){e.annotations=[],await Y(e)}var De=K.defineItem(`local:wm::prefs`,{defaultValue:J});async function Oe(){let e=await De.getValue();return{...J,...e,toolConfigs:{...J.toolConfigs,...e?.toolConfigs}}}async function X(e){await De.setValue(e)}var ke=K.defineItem(`local:wm::fabPos`,{defaultValue:{side:`right`,y:30}});async function Ae(){return await ke.getValue()}async function je(e){await ke.setValue(e)}var Me=`
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
  :host{all:initial}

  .wm-wrap{
    position:fixed;
    font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',sans-serif;
    z-index:2147483647;pointer-events:none;cursor:default;
    transition:left .2s ease,right .2s ease;
  }
  .wm-wrap.dragging{transition:none}

  /* FAB */
  .wm-btn{
    position:relative;pointer-events:auto;
    width:36px;height:36px;border-radius:50%;
    border:1px solid rgba(0,0,0,.12);
    background:#fff;color:#444;cursor:pointer;
    display:flex;align-items:center;justify-content:center;
    box-shadow:0 2px 8px rgba(0,0,0,.12),0 1px 3px rgba(0,0,0,.08);
    transition:all .15s ease;padding:0;
  }
  .wm-btn:hover{
    box-shadow:0 4px 12px rgba(0,0,0,.15),0 2px 4px rgba(0,0,0,.1);
    transform:scale(1.06);color:#222;
  }
  .wm-btn:active{transform:scale(.93)}
  .wm-btn svg{width:18px;height:18px}

  /* Panel */
  .wm-panel{
    position:absolute;top:calc(100% + 6px);right:0;
    display:flex;flex-direction:column;
    background:#fff;
    border-radius:10px;
    border:1px solid rgba(0,0,0,.1);
    box-shadow:0 4px 16px rgba(0,0,0,.1),0 1px 4px rgba(0,0,0,.06);
    overflow:hidden;pointer-events:none;
    max-height:0;opacity:0;width:48px;
    transition:max-height .25s cubic-bezier(.4,0,.2,1),opacity .15s ease,width .2s ease;
  }
  .wm-panel.open{
    max-height:520px;opacity:1;pointer-events:auto;
    width:48px;
  }
  .wm-panel.open.sub-expanded{width:220px}

  .wm-wrap.expand-up .wm-panel{
    top:auto;bottom:calc(100% + 6px);
  }
  .wm-wrap.left .wm-panel{
    right:auto;left:0;
  }

  /* Tools content */
  .wm-tools-content{
    display:flex;flex-direction:row;align-items:stretch;
    max-height:420px;overflow:hidden;
  }

  /* Sub-panel area */
  .wm-sub-area{
    width:0;overflow:hidden;opacity:0;
    transition:width .18s ease,opacity .12s ease;
    display:flex;flex-direction:column;
    border-left:1px solid transparent;
    flex-shrink:0;
  }
  .wm-sub-area.expanded{
    width:150px;opacity:1;overflow-y:auto;
    border-left-color:#eee;
  }

  .wm-sub-content{
    display:none;flex-direction:column;
    padding:8px 6px;gap:6px;
  }
  .wm-sub-content.active{display:flex}

  .wm-sub-label{
    font-size:9px;color:#999;
    text-transform:uppercase;letter-spacing:.4px;
    user-select:none;margin-bottom:2px;
  }

  .wm-colors{display:flex;flex-wrap:wrap;gap:4px}
  .wm-dot{
    width:16px;height:16px;border-radius:50%;border:2px solid transparent;
    cursor:pointer;transition:transform .1s,border-color .1s;padding:0;
    outline:none;flex-shrink:0;
  }
  .wm-dot:hover{transform:scale(1.2)}
  .wm-dot.active{border-color:#333;box-shadow:0 0 0 1px rgba(0,0,0,.1)}
  .wm-dot-plus{
    background:#f5f5f5 !important;
    color:#999;font-size:12px;font-weight:bold;
    line-height:16px;text-align:center;
    border-color:#ddd;border-style:dashed;
  }
  .wm-dot-plus:hover{background:#eee !important;color:#666}
  .wm-dot-plus.active{border-color:#2196F3;border-style:solid}
  .wm-picker-wrap{margin-top:4px}

  .wm-styles{display:flex;flex-wrap:wrap;gap:3px;margin-bottom:4px}
  .wm-style-btn{
    height:24px;min-width:24px;padding:0 5px;border-radius:4px;
    border:1px solid #ddd;
    background:#fafafa;color:#666;
    cursor:pointer;font-size:10px;line-height:24px;text-align:center;
    transition:all .1s;user-select:none;
  }
  .wm-style-btn:hover{background:#eee;color:#333;border-color:#ccc}
  .wm-style-btn.active{
    border-color:#2196F3;background:#E3F2FD;color:#1976D2;
  }

  /* Tool column */
  .wm-tools{
    width:48px;flex-shrink:0;
    display:flex;flex-direction:column;align-items:center;
    padding:6px 0;gap:1px;
    overflow-y:auto;overflow-x:hidden;
  }

  .wm-tool-wrap{
    display:flex;flex-direction:column;align-items:center;position:relative;
  }
  .wm-tool{
    width:32px;height:32px;border-radius:6px;border:none;
    background:transparent;color:#555;
    cursor:pointer;display:flex;align-items:center;justify-content:center;
    padding:0;transition:all .12s ease;
    user-select:none;
  }
  .wm-tool:hover{background:#f0f0f0;color:#222}
  .wm-tool.active{
    background:#E3F2FD;color:#1976D2;
  }
  .wm-tool svg{width:16px;height:16px}

  .wm-badge{
    position:absolute;bottom:1px;right:2px;
    width:7px;height:7px;border-radius:50%;
    border:1.5px solid #fff;
    pointer-events:none;
  }

  .wm-label{display:none}
  .wm-sep{width:24px;height:1px;background:#eee;margin:4px 0}

  /* Onboarding tooltip */
  .wm-onboard{
    position:absolute;top:50%;right:calc(100% + 8px);
    transform:translateY(-50%);
    background:#333;color:#fff;
    padding:6px 12px;border-radius:6px;
    font-size:12px;white-space:nowrap;
    pointer-events:auto;
    box-shadow:0 2px 8px rgba(0,0,0,.2);
    animation:wmPulse 2s ease-in-out infinite;
  }
  .wm-onboard::after{
    content:'';position:absolute;top:50%;left:100%;
    transform:translateY(-50%);
    border:5px solid transparent;border-left-color:#333;
  }
  .wm-wrap.left .wm-onboard{
    right:auto;left:calc(100% + 8px);
  }
  .wm-wrap.left .wm-onboard::after{
    left:auto;right:100%;
    border-left-color:transparent;border-right-color:#333;
  }
  @keyframes wmPulse{
    0%,100%{opacity:1}
    50%{opacity:.7}
  }
`;function Z(e,t){let n=document.createElement(e);return t&&Object.assign(n,t),n}function Ne(e,t,n,r){let i=document.createElement(`div`);i.id=`wm-root`,i.style.cssText=`all:initial;position:fixed;top:0;right:0;width:0;height:0;z-index:2147483647;pointer-events:none;`,document.documentElement.appendChild(i);let a=i.attachShadow({mode:`closed`}),s=document.createElement(`style`);s.textContent=Me,a.appendChild(s);let c=Z(`div`,{className:`wm-wrap`});a.appendChild(c);let l=`right`,u=30;function d(e){e?c.classList.remove(`dragging`):c.classList.add(`dragging`),c.style.top=u+`%`,l===`right`?(c.style.right=`12px`,c.style.left=`auto`,c.classList.remove(`left`)):(c.style.left=`12px`,c.style.right=`auto`,c.classList.add(`left`))}Ae().then(e=>{l=e.side,u=e.y,d(!1),requestAnimationFrame(()=>c.classList.remove(`dragging`))}),d(!1);let f=null;function p(e){e.target.closest(`.wm-panel`)||(f={startX:e.clientX,startY:e.clientY,moved:!1},e.currentTarget.setPointerCapture(e.pointerId),e.preventDefault())}function h(t){if(!f)return;let n=t.clientX-f.startX,r=t.clientY-f.startY;if(!f.moved&&Math.abs(n)+Math.abs(r)<4)return;f.moved=!0,e.open&&P(),c.classList.add(`dragging`);let i=window.innerHeight,a=window.innerWidth;u=Math.max(20,Math.min(t.clientY,i-20))/i*100,c.style.top=u+`%`,t.clientX<a/2?(c.style.left=Math.max(0,t.clientX-20)+`px`,c.style.right=`auto`):(c.style.right=Math.max(0,a-t.clientX-20)+`px`,c.style.left=`auto`)}function g(e){if(!f)return;let t=f.moved;if(f=null,!t)return;let n=window.innerWidth;l=e.clientX<n/2?`left`:`right`,u=Math.max(5,Math.min(90,u)),d(!0),je({side:l,y:u})}let _=Z(`button`,{className:`wm-btn`,title:`Web Marker`});_.innerHTML=o.pen,_.style.pointerEvents=`auto`,c.appendChild(_);let v=Z(`div`,{className:`wm-panel`});c.appendChild(v);let y=Z(`div`,{className:`wm-tools-content`});v.appendChild(y);let b=null;function x(){v.classList.toggle(`sub-expanded`,!!b)}_.addEventListener(`pointerdown`,p),_.addEventListener(`pointermove`,h),_.addEventListener(`pointerup`,t=>{let n=f?.moved;g(t),n||(e.open?P():N())}),_.style.touchAction=`none`,console.log(`[WebMarker] FAB event listeners attached`);let S=Z(`div`,{className:`wm-tools`});y.appendChild(S);let C=Z(`div`,{className:`wm-sub-area`});y.appendChild(C);let w=ee(),T={},D={},O={};for(let t of w)if(t.isAnnotator&&(t.colors.length>0||t.styles&&t.styles.length>0)){let r=Fe(t,e,r=>{D[t.name]&&(D[t.name].style.background=r),e.color=r,e.prefs.toolConfigs[t.name]?e.prefs.toolConfigs[t.name].color=r:e.prefs.toolConfigs[t.name]={color:r},Q(e),n?.(e.tool,e.color)},r=>{e.style=r,e.prefs.toolConfigs[t.name]?e.prefs.toolConfigs[t.name].style=r:e.prefs.toolConfigs[t.name]={color:t.defaultColor,style:r},n?.(e.tool,e.color)});C.appendChild(r),O[t.name]=r}let k=w.filter(e=>e.isAnnotator),A=w.filter(e=>!e.isAnnotator);for(let t of k){let{wrap:n,btn:r}=Pe(t,e,D);S.appendChild(n),T[t.name]=r}k.length>0&&A.length>0&&S.appendChild(Z(`div`,{className:`wm-sep`}));for(let t of A){let{wrap:n,btn:r}=Pe(t,e,D);S.appendChild(n),T[t.name]=r}S.appendChild(Z(`div`,{className:`wm-sep`}));let j=Z(`div`,{className:`wm-tool-wrap`}),M=Z(`button`,{className:`wm-tool`});M.innerHTML=o.trash,M.title=U(`tool.clearAll`),j.appendChild(M),S.appendChild(j);function N(){console.log(`[WebMarker] openPanel`),e.open=!0,e.annotateMode=!0,v.classList.add(`open`),x(),_.innerHTML=o.close;let t=_.getBoundingClientRect(),n=window.innerHeight-t.bottom;c.classList.toggle(`expand-up`,n<400)}function P(){console.log(`[WebMarker] closePanel`),e.open=!1,e.annotateMode=!1,v.classList.remove(`open`,`sub-expanded`),_.innerHTML=o.pen,L(),F()}function F(){b=null,C.classList.remove(`expanded`),v.classList.remove(`sub-expanded`),Object.values(O).forEach(e=>e.classList.remove(`active`))}function te(e){if(b===e){F();return}F(),O[e]&&(O[e].classList.add(`active`),C.classList.add(`expanded`),b=e,v.classList.add(`sub-expanded`),I(e))}function I(t){let n=O[t];n&&n.querySelectorAll(`.wm-dot`).forEach(t=>{t.classList.toggle(`active`,t.dataset.color===e.color)})}function L(){e.tool=null,e.color=null,e.style=null,document.body.classList.remove(`wm-eraser`),Object.values(T).forEach(e=>e.classList.remove(`active`)),Q(e),F(),n?.(null,null)}function R(t,r){let i=E(t);if(!i)return;if(e.tool===t&&!r){L();return}e.tool=t,document.body.classList.toggle(`wm-eraser`,t===`eraser`);let a=e.prefs.toolConfigs[t];i.isAnnotator&&i.colors.length>0?(e.color=a?.color||i.defaultColor,e.style=a?.style||i.defaultStyle||null):(e.color=null,e.style=null),Object.entries(T).forEach(([e,n])=>n.classList.toggle(`active`,e===t)),r&&O[t]?te(t):F(),Q(e),n?.(e.tool,e.color)}if(Object.keys(T).forEach(t=>{T[t].addEventListener(`click`,e=>{e.preventDefault(),R(t,!0)}),T[t].addEventListener(`contextmenu`,n=>{if(n.preventDefault(),R(t,!1),E(t)?.isAnnotator&&e.color&&r){let n=window.getSelection();n&&!n.isCollapsed&&n.rangeCount>0&&n.toString().trim()&&r(t,e.color,e.style||void 0)}})}),M.addEventListener(`click`,()=>{e.annotations.length!==0&&(m(),t())}),!e.prefs.onboardingDone){let t=Z(`div`,{className:`wm-onboard`});t.textContent=U(`ui.onboardTip`),c.appendChild(t);let n=()=>{t.remove(),e.prefs.onboardingDone=!0,X(e.prefs)};_.addEventListener(`click`,n,{once:!0}),setTimeout(n,15e3)}return{host:i,deactivate:L,openPanel:N,closePanel:P}}function Pe(e,t,n){let r=Z(`div`,{className:`wm-tool-wrap`}),i=Z(`button`,{className:`wm-tool`});if(i.dataset.tool=e.name,i.title=U(e.label),i.innerHTML=e.icon,r.appendChild(i),e.isAnnotator&&e.colors.length>0){let i=Z(`span`,{className:`wm-badge`}),a=t.prefs.toolConfigs[e.name];i.style.background=a?.color||e.defaultColor,r.appendChild(i),n[e.name]=i}return{wrap:r,btn:i}}function Fe(e,t,n,r){let i=Z(`div`,{className:`wm-sub-content`});if(i.dataset.tool=e.name,e.styles&&e.styles.length>0){let n=Z(`div`,{className:`wm-sub-label`});n.textContent=U(`ui.style`),i.appendChild(n);let a=Z(`div`,{className:`wm-styles`}),o=t.prefs.toolConfigs[e.name]?.style||e.defaultStyle||e.styles[0].name;e.styles.forEach(e=>{let t=Z(`button`,{className:`wm-style-btn`});t.dataset.style=e.name,t.title=U(e.label),t.textContent=e.icon||U(e.label).charAt(0),e.name===o&&t.classList.add(`active`),t.addEventListener(`click`,n=>{n.stopPropagation(),a.querySelectorAll(`.wm-style-btn`).forEach(e=>e.classList.remove(`active`)),t.classList.add(`active`),r?.(e.name)}),a.appendChild(t)}),i.appendChild(a)}let a=Z(`div`,{className:`wm-sub-label`});a.textContent=U(`ui.color`),i.appendChild(a);let o=Z(`div`,{className:`wm-colors`}),s=t.prefs.toolConfigs[e.name]?.color||e.defaultColor;e.colors.forEach(e=>{let t=Z(`button`,{className:`wm-dot`});t.style.background=e,t.dataset.color=e,t.title=e,e===s&&t.classList.add(`active`),t.addEventListener(`click`,r=>{r.stopPropagation(),o.querySelectorAll(`.wm-dot`).forEach(e=>e.classList.remove(`active`)),c.classList.remove(`active`),t.classList.add(`active`),n(e)}),o.appendChild(t)});let c=Z(`button`,{className:`wm-dot wm-dot-plus`});c.textContent=`+`,c.title=U(`ui.customColor`),o.appendChild(c),i.appendChild(o);let l=Z(`div`,{className:`wm-picker-wrap`});l.style.display=`none`;let u=de(s,t.prefs.recentColors||[],e=>{o.querySelectorAll(`.wm-dot:not(.wm-dot-plus)`).forEach(e=>e.classList.remove(`active`)),c.classList.add(`active`),n(e)});return l.appendChild(u.getStyleElement()),l.appendChild(u.element),i.appendChild(l),c.addEventListener(`click`,e=>{e.stopPropagation();let t=l.style.display!==`none`;l.style.display=t?`none`:`block`}),i}function Q(e){if(!e.tool){C(null);return}let t=E(e.tool);if(!t){C(null);return}C(t.cursor(e.color||t.defaultColor,e.style||void 0))}var Ie=`
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
  :host{all:initial}

  .wm-mini{
    position:fixed;
    display:flex;align-items:center;gap:1px;
    background:#fff;
    border-radius:8px;
    padding:3px;
    border:1px solid rgba(0,0,0,.1);
    box-shadow:0 3px 12px rgba(0,0,0,.1),0 1px 4px rgba(0,0,0,.06);
    z-index:2147483647;
    pointer-events:none;
    opacity:0;transform:translateY(4px);
    transition:opacity .12s ease,transform .12s ease;
    font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
    cursor:default;
  }
  .wm-mini.visible{
    opacity:1;transform:translateY(0);
    pointer-events:auto;
  }
  .wm-mini.above{
    transform:translateY(-4px);
  }
  .wm-mini.above.visible{
    transform:translateY(0);
  }

  .wm-mini-btn{
    position:relative;
    width:28px;height:28px;border-radius:6px;border:none;
    background:transparent;color:#555;
    cursor:pointer;display:flex;align-items:center;justify-content:center;
    padding:0;transition:all .1s;
  }
  .wm-mini-btn:hover{background:#f0f0f0;color:#222}
  .wm-mini-btn:active{transform:scale(.9)}
  .wm-mini-btn svg{width:15px;height:15px}

  .wm-mini-badge{
    position:absolute;bottom:1px;right:1px;
    width:7px;height:7px;border-radius:50%;
    border:1.5px solid #fff;
    pointer-events:none;
  }

  .wm-mini-sep{
    width:1px;height:18px;background:#eee;margin:0 2px;
    flex-shrink:0;
  }

  .wm-mini-expand{
    width:24px;height:28px;border-radius:6px;border:none;
    background:transparent;color:#bbb;
    cursor:pointer;display:flex;align-items:center;justify-content:center;
    padding:0;transition:all .1s;
  }
  .wm-mini-expand:hover{background:#f0f0f0;color:#555}
  .wm-mini-expand svg{width:12px;height:12px}

  .wm-mini-hint{
    position:absolute;top:100%;left:50%;transform:translateX(-50%);
    margin-top:4px;
    font-size:10px;color:#888;
    background:#fff;border:1px solid #e0e0e0;
    border-radius:4px;padding:2px 7px;
    box-shadow:0 2px 6px rgba(0,0,0,.08);
    white-space:nowrap;
    pointer-events:none;
  }
`,Le=`<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="6" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="18" cy="12" r="2"/></svg>`;function Re(e,t,n){let r=document.createElement(`div`);r.id=`wm-mini-root`,r.style.cssText=`all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;pointer-events:none;`,document.documentElement.appendChild(r);let i=r.attachShadow({mode:`closed`}),a=document.createElement(`style`);a.textContent=Ie,i.appendChild(a);let o=document.createElement(`div`);o.className=`wm-mini`,i.appendChild(o);let s=!1,c=!e.prefs.firstAnnotationDone;function l(){o.innerHTML=``;let r=e.prefs.miniToolbarSlots;for(let n of r){let r=E(n);if(!r||!r.isAnnotator)continue;let i=document.createElement(`button`);i.className=`wm-mini-btn`,i.innerHTML=r.icon,i.title=U(r.label);let a=e.prefs.toolConfigs[n],s=a?.color||r.defaultColor,c=document.createElement(`span`);c.className=`wm-mini-badge`,c.style.background=s,i.appendChild(c),i.addEventListener(`click`,e=>{e.preventDefault(),e.stopPropagation(),t(n,{color:a?.color||r.defaultColor,style:a?.style||r.defaultStyle}),d()}),o.appendChild(i)}let i=document.createElement(`div`);i.className=`wm-mini-sep`,o.appendChild(i);let a=document.createElement(`button`);if(a.className=`wm-mini-expand`,a.innerHTML=Le,a.title=U(`ui.expandPanel`),a.addEventListener(`click`,e=>{e.preventDefault(),e.stopPropagation(),d(),n()}),o.appendChild(a),c){let e=document.createElement(`div`);e.className=`wm-mini-hint`,e.textContent=U(`ui.clickToAnnotate`),o.appendChild(e),c=!1}}function u(t){if(e.annotateMode)return;l();let n=window.innerWidth,r=window.innerHeight,i=t.right+8,a=t.bottom+8,c=!1;i+160>n&&(i=t.left-160-8,i<0&&(i=Math.max(4,t.left))),a+42>r&&(a=t.top-42-8,c=!0),i=Math.max(4,Math.min(i,n-160-4)),a=Math.max(4,Math.min(a,r-42-4)),o.style.left=i+`px`,o.style.top=a+`px`,o.classList.toggle(`above`,c),requestAnimationFrame(()=>{o.classList.add(`visible`)}),s=!0}function d(){o.classList.remove(`visible`),s=!1}function f(){r.remove()}return{show:u,hide:d,destroy:f,isVisible:()=>s}}var ze=K.defineItem(`local:wm::enabled`,{defaultValue:!0}),Be=e({matches:[`*://*/*`,`file:///*`],runAt:`document_idle`,async main(){if(console.log(`[WebMarker] Content script starting...`),!await ze.getValue()){console.log(`[WebMarker] Disabled, exiting`);return}let e=Ce();e.prefs=await Oe(),se(e.prefs.locale||H()),console.log(`[WebMarker] Locale:`,e.prefs.locale||H());let t=null,a=null;h(),t=Ne(e,async()=>{await Ee(e)},(t,n)=>{X(e.prefs)},(e,t,n)=>{o(e,t,n)}),console.log(`[WebMarker] UI created successfully`),a=Re(e,(e,t)=>{o(e,t.color,t.style)},()=>{t?.openPanel()}),await v(),console.log(`[WebMarker] Init complete, annotations restored`),document.addEventListener(`mouseup`,m,!0),document.addEventListener(`click`,_,!0),document.addEventListener(`mousedown`,g,!0),document.addEventListener(`keydown`,n=>{n.key===`Escape`&&(e.tool?(n.preventDefault(),t?.deactivate()):e.open&&(n.preventDefault(),t?.closePanel()),a?.isVisible()&&a.hide())},!0),n.runtime.onMessage.addListener(e=>{e?.type===`wm:toggle`&&(e.enabled===!1?(t&&(t.host.style.display=`none`,t.deactivate()),a?.hide()):e.enabled===!0&&t&&(t.host.style.display=``))});function o(t,n,r){let i=window.getSelection();if(!i||i.isCollapsed||!i.rangeCount)return;let a=i.getRangeAt(0),o=i.toString();if(!o.trim())return;let c=u(a.commonAncestorContainer),p=l(c,a.startContainer,a.startOffset),m=l(c,a.endContainer,a.endOffset);if(p==null||m==null||p>=m)return;let h=c.textContent,g=`wm`+Math.random().toString(36).slice(2,9)+Date.now().toString(36),_=E(t),v={id:g,type:t,color:n,style:r||void 0,xpath:s(c),s:p,e:m,text:o,cb:h.substring(Math.max(0,p-30),p),ca:h.substring(m,m+30),ts:Date.now()},y=d(c,p,m);y.length!==0&&(f(y,g,t,n,r,_?.apply),e.annotations.push(v),Y(e),e.prefs.firstAnnotationDone||(e.prefs.firstAnnotationDone=!0,X(e.prefs)),i.removeAllRanges())}function m(t){let n=document.getElementById(`wm-root`);if(n&&n.contains(t.target))return;let r=document.getElementById(`wm-mini-root`);if(!(r&&r.contains(t.target))){if(e.annotateMode&&e.tool&&e.tool!==`eraser`&&e.color){o(e.tool,e.color,e.style||void 0);return}setTimeout(()=>{let t=window.getSelection();if(!t||t.isCollapsed||!t.rangeCount){a?.hide();return}if(!t.toString().trim()){a?.hide();return}if(e.annotateMode)return;let n=t.getRangeAt(0).getBoundingClientRect();a?.show(n)},10)}}function g(e){let t=document.getElementById(`wm-mini-root`);t&&t.contains(e.target)||a?.isVisible()&&a.hide()}function _(t){if(e.tool!==`eraser`)return;let n=t.target.closest(`.`+r);if(!n)return;t.preventDefault(),t.stopPropagation();let a=n.getAttribute(i);a&&(p(a),e.annotations=e.annotations.filter(e=>e.id!==a),Y(e))}async function v(){let t=await Te();for(let n of t){let t=c(n.xpath);if(!t)continue;let r=n.s,i=n.e;if(t.textContent.substring(r,i)!==n.text){let e=t.textContent.indexOf(n.text);if(e===-1)continue;r=e,i=e+n.text.length}let a=d(t,r,i);if(a.length>0){let t=E(n.type);f(a,n.id,n.type,n.color,n.style,t?.apply),e.annotations.push(n)}}}}}),Ve={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},He=class e extends Event{static EVENT_NAME=$(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function $(e){return`${n?.runtime?.id}:marker:${e}`}var Ue=typeof globalThis.navigation?.addEventListener==`function`;function We(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),Ue?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new He(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new He(e,t)),t=e)},1e3))}}}var Ge=class e{static SCRIPT_STARTED_MESSAGE_TYPE=$(`wxt:content-script-started`);id;abortController;locationWatcher=We(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return n.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?$(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),Ve.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{!(e instanceof CustomEvent)||!this.verifyScriptStartedEvent(e)||this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},Ke={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=Be;return await e(new Ge(`marker`,t))}catch(e){throw Ke.error(`The content script "marker" crashed on startup!`,e),e}})()})();
marker;